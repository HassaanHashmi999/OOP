//Airline
#include<iostream>
#include<fstream>
#include <string>
#include <cstdlib>
#include <cstring>
using namespace std;

class Menu
{
    int sys;

public:
    Menu()
    {

        cout << "           \t\t\t\tNEW-PAK AIRLINE FLIGHT SYESTEM (NPAFS)\n";

        cout << "\n \n\n\t\t   Welcome!";
        cout << "\n \n\t\t  Main Menu\n";
        cout << " \t-----------------------------\n";
        cout << "\n \tPress the Option of your Desire\n";
        cout << " --------------------------------------------\n";
        cout << "1. Flight Details \t2. Rates/Per_Hour\n";
        cout << "3. Login/ChangePASS     4. Register" << endl;


        cout << "Please Enter your Preferred Choice :- " << endl;
    }
    void Pmenu()
    {
        cout << "\n1)BOOK FLIGHT\n";
        cout << "2)CANCEL Flight( With Panelty)\n";
        cout << endl;

    }

};
class panel
{
private:
    Menu m;
protected:
    int choice;
    int chk;
    int log;

public:


    void Panel(int c)
    {
        int command = 0;
        string name, password, inName, inPassword, registerName, registerPassword;
        Panel(c, command, name, password, inName, inPassword, registerName, registerPassword);
    }
    void Panel(int c, int command, string  name, string  password, string inName, string  inPassword, string registerName, string registerPassword)
    {
        if (c == 1)
        {
            cout << "Flight time";
        }
        if (c == 2)
        {
            cout << "Rs.10,000 for a local flight and Rs.20,000 for international flights__/plus tax may apply 5% or 10% tax on local and international flights respectively may vary on the route\n";
        }

        if (c == 3)
        {
            this->choice = 0;

        }
        if (c == 4)
        {
            this->choice = 1;
        }
        if (choice == 0)
        {
            cout << "LOGIN For \n 1)Admin \n 2)USER \n 3)MAIN MENU \n Choose:-";
            cin >> chk;
            if (chk == 1)
            {

                cout << "1)MAIN MENU\n2)login)\n"
                    << "Command: ";
                cin >> command;

                if (command == 1)
                {
                    Menu access;
                    cin >> choice;
                    Panel(choice);
                }

                if (command == 2)
                {

                    ifstream f("admin.txt");
                    if (!f.is_open())
                    {
                        cout << "could not open file\n";
                        Menu access;
                        cin >> choice;
                        Panel(choice);
                    }
                    getline(f, name, '\n');
                    getline(f, password, '\n');

                    f.close(); //you don't need it open now, since you have the name and password from the file

                    //login
                    while (1)
                    {

                        cout << "\n\n\n"
                            << "Enter Username: ";
                        cin >> inName;
                        cout << "Enter Password: ";
                        cin >> inPassword;

                        if (inName == name && inPassword == password)
                        {
                            log = 1;
                            cout << "Login Successful\n"
                                << "Welcome, "
                                << inName;
                            break;
                        }
                        cout << "Incorrect username or Password\nTRY AGAIN";
                        Menu access;
                        cin >> choice;
                        Panel(choice);
                    }

                }
                cout << "\n\n\n\n\n"; //give it 5 newlines

            }

            if (chk == 2)
            {

                cout << "1)MAIN MENU\n2)login)\n3)ChangePass\n"
                    << "Command: ";
                cin >> command;

                if (command == 1)
                {
                    Menu access;
                    cin >> choice;
                    Panel(choice);
                }

                if (command == 2)
                {

                    ifstream f("user.txt");
                    if (!f.is_open())
                    {
                        cout << "could not open file\n";

                    }
                    getline(f, name, '\n');
                    getline(f, password, '\n');

                    f.close(); //you don't need it open now, since you have the name and password from the file

                    //login
                    while (1)
                    {

                        cout << "\n\n\n"
                            << "Enter Username: ";
                        cin >> inName;
                        cout << "Enter Password: ";
                        cin >> inPassword;

                        if (inName == name && inPassword == password)
                        {
                            log = 1;
                            cout << "Login Successful\n"
                                << "Welcome, "
                                << inName;
                            break;

                        }
                        cout << "Incorrect Name or Password\nTRY AGAIN";

                    }

                    m.Pmenu();
                }
                if (command == 3)
                {

                    ifstream f("user.txt");
                    if (!f.is_open())
                    {
                        cout << "could not open file\n";

                    }
                    getline(f, name, '\n');
                    getline(f, password, '\n');

                    f.close(); //you don't need it open now, since you have the name and password from the file

                    //login
                    while (1)
                    {

                        cout << "\n\n\n"
                            << "Enter Username: ";
                        cin >> inName;
                        cout << "Enter Password: ";
                        cin >> inPassword;

                        if (inName == name && inPassword == password)
                        {
                            log = 1;
                            cout << "Login Successful\n"
                                << "Welcome, "
                                << inName << endl;
                            break;

                        }
                        cout << "Incorrect Name or Password\nTRY AGAIN";

                    }
                    cout << "New Password: ";
                    ofstream g("user.txt");
                    cin >> registerPassword;
                    g << registerPassword;
                    cout << "Password Changed";
                    g.close();
                }
                cout << "\n\n\n\n\n";

            }



            if (chk == 3)
            {
                Menu access;
                cin >> choice;
                Panel(choice);
            }
        }



    }

};
class Passenger :public panel
{
    int age;
    bool isdependent = 1;
    string cnic;

public:

    void register_user(int a, int c, int command, string  name, string  password, string inName, string  inPassword, string registerName, string registerPassword)
    {
        age = a;
        cout << "First time user of " << age << endl;
        if (age < 18)
        {

            cout << "The age under 18 is not permitted\n Please enter CNIC of a Guardian:";
            cin >> cnic;
            if (cnic.length() < 13 || cnic.length() > 13)
            {
                cout << "Not a valid CNIC";
                isdependent = 0;
            }
        }
        if (isdependent)
        {
            cout << "Your age is 18 or above\n CONGRATULATION!!!\n";

            cout << "REGISTER For \n 1)Admin \n 2)USER \n 3)MAIN MENU \n Choose:-";
            cin >> chk;
            cout << "Please Enter your Valid CNIC:";
            cin >> cnic;
            if (cnic.length() < 13 || cnic.length() > 13)
            {
                cout << "Not a valid CNIC\n";
                isdependent = 0;
            }

            if (chk == 1 && isdependent)
            {


                //open file for registration
                ofstream g("admin.txt");
                if (!g.is_open())
                {
                    cout << "could not open file\n";
                    Menu access;
                    cin >> choice;
                    Panel(choice);
                }
                cout << "\n\n\n"
                    << "New Username: ";
                cin >> registerName;
                cout << "New Password: ";
                cin >> registerPassword;
                g << registerName;
                g << '\n';
                g << registerPassword;
                g.close();

            }
            if (chk == 2 && isdependent)
            {
                //open file for registration
                ofstream g("user.txt");
                if (!g.is_open())
                {
                    cout << "could not open file\n";
                    Menu access;
                    cin >> choice;
                    Panel(choice);
                }
                cout << "\n\n\n"
                    << "New Username: ";
                cin >> registerName;
                cout << "New Password: ";
                cin >> registerPassword;
                g << registerName;
                g << '\n';
                g << registerPassword;
                g.close();
            }
            if (chk == 3)
            {
                Menu access;
                cin >> choice;
                Panel(choice);
            }
        }
    }


};
class user
{
    bool islocal;
    bool haspass;
    bool isdep;
public:
    user(bool isL, bool isd, bool pass) :islocal{ isL }, isdep{ isd }, haspass{ pass }
    {
        if (islocal)
            cout << "The person is a local Pakistani\n";
        if (haspass)
            cout << "The user can take International flights\n";
        if (isdep)
            cout << "The passenger is dependent on a Guardian\n";

    }


};
class booking
{
protected:
	string to,from,details,flight;
	int n=0,n1=0;
	public:
 void BOOK()
	{
		cout << "\n\t\tSelect Your City of Arrival\n";
                cout << "\t\t---------------------------\n";
                cout << "\t1. Karachi\n";
                cout << "\t2. Quetta\n";
                cout << "\t3. Islamabad\n";
                cout << "\t4. Peshawar\n";
                cout << "\t5. Lahore\n";
                

                cout << "Please Input Your Choice :- ";
                cin >>n;

                switch(n)
                {
                    case 1:
                        to="Karachi";
                        break;
                    case 2:
                        to="Quetta";
                        break;
                    case 3:
                        to="Islamabad";
                        break;
                    case 4:
                        to="Peshawar";
                        break;
                    case 5:
                        to="Lahore";
                        break;
                    
                   default:
                        cout << "Invalid choice . Please Try Again.\n";
                    
                }
                cout << "\n\t\tSelect Your City of Departure\n";
                cout << "\t\t---------------------------\n";
                cout << "\t1. Karachi\n";
                cout << "\t2. Quetta\n";
                cout << "\t3. Islamabad\n";
                cout << "\t4. Peshawar\n";
                cout << "\t5. Lahore\n";
                

                cout << "Please Input Your Choice :- ";
                cin >>n1;

                switch(n1)
                {
                    case 1:
                        from="Karachi";
                        break;
                    case 2:
                        from="Quetta";
                        break;
                    case 3:
                        from="Islamabad";
                        break;
                    case 4:
                        from="Peshawar";
                        break;
                    case 5:
                        from="Lahore";
                        break;
                    
                   default:
                        cout << "Invalid choice . Please Try Again.\n";
                        
                }
           
	}
	
};
struct date
{
	int d,m,y;
};
class airport:public booking
{
	string location,loc;
	
	public:
	void port()
	{   location=from;
		loc=to;	
		cout<<"THE location of departure is "<<location<<endl;
		cout<<"Enter the date of the booking:(DD/MM/YYYY)\n";
		cout<<"DAY:";
		date dat;
		cin>>dat.d;
		cout<<"MONTH:";
		cin>>dat.m;
		cout<<"YEAR:";
		cin>>dat.y;
		cout<<"Flights leaving from "<<location<<" to " <<loc<<" on "<<dat.d<<"/"<<dat.m<<"/"<<dat.y<<endl;
	}
	
};
class flight_T:public booking
{
	string flight[5][15];
	public:
	void fly()
	{
		for(int i=0;i<5;i++)
		{
			
				if(i==0)
				{
				for(int j=0;j<15;j++)
				{
				if(j==0)
				flight[i][j]="Karachi";
				if(j==1)
				flight[i][j]="Islamabad___3:15AM";
				if(j==2)
				flight[i][j]="Lahore";
				if(j==3)
				flight[i][j]="Islamabad___5:00AM";
				if(j==4)
				flight[i][j]="Quetta___6:15AM";
				if(j==5)
				flight[i][j]="Peshawar____6:45AM";
				if(j=6)
				flight[i][j]="Islamabad";
				if(j=7)
				flight[i][j]="Islamabad";
				if(j=8)
				flight[i][j]="Islamabad";
				if(j==9)
				flight[i][j]="Islamabad";
				if(j==10)
				flight[i][j]="Lahore____3:50AM";
				if(j==11)
				flight[i][j]="Islamabad___5:00AM";
				if(j==12)
				flight[i][j]="Quetta___6:15AM";
				if(j==13)
				flight[i][j]="Peshawar____6:45AM";
				if(j=14)
				flight[i][j]="Islamabad";
				}
				}
				if(i==1)
				{
				
				for(int j=0;j<15;j++)
				{
				if(j==0)
				flight[i][j]="Karachi";
				if(j==1)
				flight[i][j]="Islamabad___3:15AM";
				if(j==2)
				flight[i][j]="Lahore";
				if(j==3)
				flight[i][j]="Islamabad___5:00AM";
				if(j==4)
				flight[i][j]="Quetta___6:15AM";
				if(j==5)
				flight[i][j]="Peshawar____6:45AM";
				if(j=6)
				flight[i][j]="Islamabad";
				if(j=7)
				flight[i][j]="Islamabad";
				if(j=8)
				flight[i][j]="Islamabad";
				if(j==9)
				flight[i][j]="Islamabad";
				if(j==10)
				flight[i][j]="Lahore____3:50AM";
				if(j==11)
				flight[i][j]="Islamabad___5:00AM";
				if(j==12)
				flight[i][j]="Quetta___6:15AM";
				if(j==13)
				flight[i][j]="Peshawar____6:45AM";
				if(j=14)
				flight[i][j]="Islamabad";
				
				}
				}
				if(i==2)
				{
				
				for(int j=0;j<15;j++)
				{
				if(j==0)
				flight[i][j]="Karachi";
				if(j==1)
				flight[i][j]="Islamabad___3:15AM";
				if(j==2)
				flight[i][j]="Lahore";
				if(j==3)
				flight[i][j]="Islamabad___5:00AM";
				if(j==4)
				flight[i][j]="Quetta___6:15AM";
				if(j==5)
				flight[i][j]="Peshawar____6:45AM";
				if(j=6)
				flight[i][j]="Islamabad";
				if(j=7)
				flight[i][j]="Islamabad";
				if(j=8)
				flight[i][j]="Islamabad";
				if(j==9)
				flight[i][j]="Islamabad";
				if(j==10)
				flight[i][j]="Lahore____3:50AM";
				if(j==11)
				flight[i][j]="Islamabad___5:00AM";
				if(j==12)
				flight[i][j]="Quetta___6:15AM";
				if(j==13)
				flight[i][j]="Peshawar____6:45AM";
				if(j=14)
				flight[i][j]="Islamabad";
				
				}
				}
				if(i==3)
				{
				
				for(int j=0;j<15;j++)
				{
				if(j==0)
				flight[i][j]="Karachi";
				if(j==1)
				flight[i][j]="Islamabad___3:15AM";
				if(j==2)
				flight[i][j]="Lahore";
				if(j==3)
				flight[i][j]="Islamabad___5:00AM";
				if(j==4)
				flight[i][j]="Quetta___6:15AM";
				if(j==5)
				flight[i][j]="Peshawar____6:45AM";
				if(j=6)
				flight[i][j]="Islamabad";
				if(j=7)
				flight[i][j]="Islamabad";
				if(j=8)
				flight[i][j]="Islamabad";
				if(j==9)
				flight[i][j]="Islamabad";
				if(j==10)
				flight[i][j]="Lahore____3:50AM";
				if(j==11)
				flight[i][j]="Islamabad___5:00AM";
				if(j==12)
				flight[i][j]="Quetta___6:15AM";
				if(j==13)
				flight[i][j]="Peshawar____6:45AM";
				if(j=14)
				flight[i][j]="Islamabad";
				
				}
				}
				if(i==4)
				{
				
				for(int j=0;j<15;j++)
				{
				if(j==0)
				flight[i][j]="Karachi";
				if(j==1)
				flight[i][j]="Islamabad___3:15AM";
				if(j==2)
				flight[i][j]="Lahore";
				if(j==3)
				flight[i][j]="Islamabad___5:00AM";
				if(j==4)
				flight[i][j]="Quetta___6:15AM";
				if(j==5)
				flight[i][j]="Peshawar____6:45AM";
				if(j=6)
				flight[i][j]="Islamabad";
				if(j=7)
				flight[i][j]="Islamabad";
				if(j=8)
				flight[i][j]="Islamabad";
				if(j==9)
				flight[i][j]="Islamabad";
				if(j==10)
				flight[i][j]="Lahore____3:50AM";
				if(j==11)
				flight[i][j]="Islamabad___5:00AM";
				if(j==12)
				flight[i][j]="Quetta___6:15AM";
				if(j==13)
				flight[i][j]="Peshawar____6:45AM";
				if(j=14)
				flight[i][j]="Islamabad";
				
				}
				}
		}
		cout<<"FROM"<<flight[0][0]<<"TO"<<flight[0][10]<<endl;
	}
	void time()
	{
		cout<<"FROM"<<flight[0][0]<<"TO"<<flight[0][10]<<endl;
		cout<<"FROM"<<flight[1][2]<<"TO"<<flight[4][2]<<endl;
	}
};


int main()
{
    bool inL = 1, isd = 1, pass = 1;
    string  name, password, inName, inPassword, registerName, registerPassword;//for registration and login
    int command = 0, age = 0, ran = 0,bk=0;
    Passenger p;
    int choice;
    cin >> choice;

    if (choice == 4) {
        cout << "Enter your age:";
        cin >> age;
        p.register_user(age, choice, command, name, password, inName, inPassword, registerName, registerPassword);
    }
    p.Panel(choice, command, name, password, inName, inPassword, registerName, registerPassword);
    if (choice != 3)
    {Menu();
    cin >> choice;
    if (choice == 4) {
        cout << "Enter your age:";
        cin >> age;
        p.register_user(age, choice, command, name, password, inName, inPassword, registerName, registerPassword);
    }
    p.Panel(choice, command, name, password, inName, inPassword, registerName, registerPassword);
    }
    if (age < 18)
        isd = 0;

    	cin>>bk;
	
	if(bk==1){
	
    cout << "Does the user have passport?\n1.Yes\n2.No\n:--";
    cin >> ran;
    if (ran == 2)
        pass = 0;
    user u(inL, isd, pass);
	airport b;
	b.BOOK();
	b.port();
	flight_T fli;
	fli.fly();
	fli.time();
}
}


