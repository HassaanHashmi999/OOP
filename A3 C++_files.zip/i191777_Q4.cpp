#include<iostream>
#include <conio.h>
using namespace std;
class ArrayInt
{
	int z;
int *arr1;
int *arr2;
public: 
ArrayInt(int l)
{
	 arr1  = new int [z];
	  
}
void input(int n)
{
	for(int i=0;i<n;i++)
    {
    	cout<<"Enter the no"<<i+1<<" element:";
    	cin>>arr1[i];
	}

}
void copy(int p);
void makeNull(int p);
void initialise(int p,int s);
void sum(int p);
void average(int p);
void contains(int p,int s);
void getIndexOf(int p, int s);
void getElement(int p, int s);
void getSubArray(int p, int s);
void sort(int size);
void reverse(int p);

};

void ArrayInt::copy(int p)
{	
	arr2  = new int [p];
    
    	cout<<"The array copied into the second array:{";
    for(int i=0;i<p;i++)
    {
    	
	arr2[i]=arr1[i];

    cout<<" "<<arr2[i];
    
}
cout<<" }"<<endl;
}
void ArrayInt::makeNull(int p)
{	
	cout<<"The array is now Null:{";
	for(int i=0;i<p;i++)
    {
	arr1[i]=0;
	cout<<" "<<arr1[i];
}
cout<<" }"<<endl;
}
void ArrayInt::initialise(int p,int s)
{
		cout<<"The array is now initialised:{";
	for(int i=0;i<p;i++)
    {
	arr1[i]=s;
	cout<<" "<<arr1[i];
}
cout<<" }"<<endl;
}

void ArrayInt::sum(int p)
{
	int sum=0;
    for(int i=0;i<p;i++)
        sum+=arr2[i];
        cout<<"The sum is "<<sum<<endl;
}
void ArrayInt::average(int p)
{
	float sum=0,avg=0;
    for(int i=0;i<p;i++)
    sum+=arr2[i];
    avg=sum/p;
    cout<<"The average is "<<avg<<endl;
}
void ArrayInt::contains(int p,int s)
{
bool h=0;
	for(int i=0;i<p;i++)
    {
	if(arr2[i]==s)
	{
		h=1;
	}
	
}
if(h)
{
	cout<<"The element exists"<<endl;
}
else
cout<<"Element doesn't exist"<<endl;
}

void ArrayInt::getIndexOf(int p, int s)
{
	bool h=0;
	for(int i=0;i<p;i++)
    {
	if(arr2[i]==s)
	{
		h=1;
	cout<<"Array contains this Element At no."<<i+1<<" at Index"<<i;
	}
}
if(h)
{
		cout<<endl;
	}
	else 
	{
	cout<<"NO!! the array does not contain this digit."<<endl;
	
}
}
void ArrayInt::getElement( int p,int s)
{
	cout<<"The element is:"<<arr2[s]<<endl;
}
void ArrayInt::getSubArray(int p, int s)
{
	cout<<"The sub Array:{";
	for(int i=p;i<s+1;i++)
    {
    cout<<" "<<arr2[i];
    
}
cout<<" }"<<endl;
}
void ArrayInt::sort(int size)
{

	int tempy;
	  for(int i=0; i<size; i++)
    {
        for(int j=i+1; j<size; j++)
        {
            
            if(arr2[j] < arr2[i])
            {
                tempy = arr2[i];
                arr2[i] = arr2[j];
                arr2[j] = tempy;
            }
        }
    }
    cout<<"The sorted Array:{";
	for(int i=0;i<size;i++)
    {
    cout<<" "<<arr2[i];
    }
    cout<<" }"<<endl;
    
    
    
    
}
void ArrayInt::reverse(int p)
{
	cout<<"The reverse Array(desending as it was ascending):{";
	for(int i=p;i>-1;i--)
    {
    cout<<" "<<arr2[i];
    }
    cout<<" }"<<endl;
}

int main()
{
    
    int n,r,w;
    cout<<"Enter the number of elements in the integer array:";
    cin>>n;
    ArrayInt ar(n);
    ar.input(n);
    ar.copy(n);
    ar.makeNull(n);
    cout<<"Enter the element you want to intialize in the array:";
    cin>>r;
    ar.initialise(n,r);
    ar.sum(n);
    ar.average(n);
    cout<<"Element to check if it is in the array or not:";
    cin>>w;
    ar.contains(n,w);
    cout<<"Enter the digit you want to get Index of:";
    cin>>w;
	ar.getIndexOf(n,w);
    cout<<"Enter the index you want to get element of:";
    cin>>w;
    ar.getElement(n,w);
    cout<<"Enter two digits to get Sub-Array(from to till)";
    cin>>r>>w;
    ar.getSubArray(r,w);
    ar.sort(n);
    ar.reverse(n);
 
 
}
