#include <iostream>
using namespace std;

int r1,r2,c1,c2;


class Matrix {

  
   int arr[20][20];
	
public:
   
   void input();
   void display();
   void operator+(Matrix x);
   void operator-(Matrix x);
   void operator*(Matrix x);
   void operator==(Matrix x);
   void operator=(Matrix x);
   void operator++();
   void operator++(int);
   
   
};


void Matrix::input()
{

  
   for (int i = 0; i < r1; i++) {

       for (int j = 0; j < c1; j++) {
			cout<<"Enter value at row "<<i+1<<" col "<<j+1<<": ";
           cin>>arr[i][j];
       }
   }
}


void Matrix::display()
{

   for (int i = 0; i < r1; i++) {
	cout<<"| ";
       for (int j = 0; j < c1; j++) {

           
           cout << arr[i][j] << " ";
       }
       
       cout <<"|"<< endl;
   }
}

void Matrix::operator+(Matrix x)
{
  
   int mat[r1][c1];

 
   for (int i = 0; i < r1; i++) {
       for (int j = 0; j < c1; j++) {

         
           mat[i][j] = arr[i][j]+ x.arr[i][j];
       }
   }

   
   for (int i = 0; i < r1; i++) {
		cout<<"| ";
       for (int j = 0; j < c1; j++) {

           
           cout << mat[i][j] << " ";
       }
       cout <<"|"<< endl;
   }
}
void Matrix::operator-(Matrix x)
{
   
   int mat[r1][c1];


   for (int i = 0; i < r1; i++) {
		
       for (int j = 0; j < c1; j++) {

           
           mat[i][j] = arr[i][j]- x.arr[i][j];
       }
   }

  
   for (int i = 0; i < r1; i++) {
   	cout<<"| ";
       for (int j = 0; j < c1; j++) {

           
           cout << mat[i][j] << " ";
       }
      cout <<"|"<< endl;
   }
}
void Matrix::operator*(Matrix x)
{
  
   int mat[r1][c2];

   
for(int i = 0; i < r1; ++i)
for(int j = 0; j < c2; ++j){
mat[i][j]=0;
for(int k = 0; k < c1; ++k)
{
mat[i][j] += arr[i][k] * x.arr[k][j];
}
}

   for (int i = 0; i < r1; i++) {
 		cout <<"| ";
       for (int j = 0; j < c1; j++) {

           
           cout << mat[i][j] << " ";
       }
       cout <<"|"<< endl;
   }
}
void Matrix::operator==(Matrix x)
{
  
int z=0;

   

   for (int i = 0; i < r1; i++) {

       for (int j = 0; j < c1; j++)
	    {

   if(arr[i][j]!=x.arr[i][j])
   {
   z=1;
   }
       }
  
   }
   if(z==1)
   {
   cout<<"Not equal matrix";
   }
   else{
   cout<<"Equal matix";
   }
   
}
void Matrix::operator=(Matrix x)
{
  


  
   for (int i = 0; i < r1; i++) {

       for (int j = 0; j < c1; j++) {

   arr[i][j]=x.arr[i][j];
  
       }
  
   }

   cout<<"\n";
}


void Matrix:: operator ++ ()
{
   for (int i = 0; i < r1; i++) {

       for (int j = 0; j < c1; j++) {

   arr[i][j]++;
  
       }
  
   }
}

void Matrix:: operator ++ (int)
{
   for (int i = 0; i < r1; i++) {

       for (int j = 0; j < c1; j++) {

   ++arr[i][j];
  
       }
  
   }
}

int main()
{

   
  
   	cout<<"Please enter the rows of Matrix 1\n";
   	cin>>r1;
   	cout<<"Please enter the columns of Matrix 1\n";
  	cin>>c1;
   
   	cout<<"Please enter the rows of Matrix 2\n";
   	cin>>r2;
   	cout<<"Please enter the columns of Matrix 2\n";
   	cin>>c2;
 
	
	Matrix mat1, mat2,mat3;

   
   	mat1.input();
	cout<<"Printing matrix 1:\n";
	mat1.display();
 
  	mat2.input();
   	cout<<"Printing matrix 2:\n";
	mat2.display();
	
	cout << "Addition of the two Matrices is : "<<endl;
   	mat1+mat2;
	
	cout << "Substraction of the two Matrices is : "<<endl;
    mat1 - mat2;
	
	cout << "Multiplication of two given Matrices is : "<<endl;
	mat1* mat2;
   
   	cout << " Matrixs are : ";
   	mat1 == mat2;
   	
   	mat3 = mat1;
    cout<<"Displaying a matrix 3 after assignment with matrix 1:\n";
    mat3.display();
    mat1.input();
	cout<<"Printing matrix 1:\n";
	mat1.display();
	cout<<"Checking matrix 3 with matrix 1 :\n";
    mat3.display();
    cout<<"\nDisplaying matrix 1 after post increment:\n";
   mat1++;
   mat1.display();
 
   cout<<"\nDisplaying matrix 2 after pre increment:\n";
   ++mat2;
   mat2.display();
     cout<<"\nDisplaying matrix 3 after assignment of matrix++ 1:\n";
   
   mat3 = mat1;
   mat3.display();

       cout<<"\nDisplaying matrix 3 after assignment of ++matrix 2 :\n";
   mat3 = mat2;
   mat3.display();
cout<<"\n";
   return 0;
}
