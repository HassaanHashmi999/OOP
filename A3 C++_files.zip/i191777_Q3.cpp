#include<iostream>
#include<string.h>
#include<conio.h>
#include<iomanip>
#include<vector>
using namespace std;
class calender

{

int Month, Year,fday;
static vector<char>tasks;

public:

 calender(int month, int year) ;
void setFirstDay() ;
void display(int reminder) ;
void printCalendar(const char **weekDays, int firstWeekDayOfMonth, int numberOfDays, int remiderDay);

};


string getMonthName(int monthNumber)
{
	string months[] ={"January", "February", "March",
					"April", "May", "June",
					"July", "August", "September",
					"October", "November", "December"
					 };

	return (months[monthNumber]);
}

calender :: calender (int month, int year)

{
Month = month;
Year = year;
}

void calender :: setFirstDay()

{

int day = 1;
int Y = Year -(14 - Month) /12;
int M = Month + 12 * ((14-Month) /12) -2;
fday = (day +Y+Y/4-Y/100+Y/400+(31*M/12) ) %7;

}

void calender :: display(int reminder)

{

int NumberofDaysInMonth;
int FirstDayofMonth = 0;
int DayOfweekCounter = 0;
int dateCounter =1;
int i = 0;
switch (Month)

{

case 1:

cout <<"January";

NumberofDaysInMonth =31;
i = 0;
break;

case 2:
i = 1;
cout<<"February ";

if(Year% 400==0 || ( Year%4==0 && Year%100 != 0) )
NumberofDaysInMonth = 29;
else
NumberofDaysInMonth = 28;

break;

case 3:
i = 2;
cout<<"March";

NumberofDaysInMonth = 31;

break;

case 4:
i = 3;
cout<<"April";

NumberofDaysInMonth = 30;

break;

case 5:
i = 4;
cout<<"May";

NumberofDaysInMonth = 31;

break;

case 6:
i = 5;
cout<<"June";

NumberofDaysInMonth = 30;

break;

case 7:
i = 6;
cout<<"July";

NumberofDaysInMonth = 31;

break;

case 8:
i = 7;
cout<<"August";

NumberofDaysInMonth = 31;

break;

case 9:
i = 8;
cout<<"September";

NumberofDaysInMonth = 30;

break;

case 10:
i = 9;
cout<<"October";

NumberofDaysInMonth = 31;

break;

case 11:
 i = 10;
cout<<"Novemeber";

NumberofDaysInMonth = 30;

break;

case 12:
 i = 11;
cout<<"December";

NumberofDaysInMonth = 31;

break;

}


	cout<<" 		Calendar :"<<Year<<endl;

	
	int current = fday;
	

	
	
	int	days = NumberofDaysInMonth;
		
		
		
		const char * week[7]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};

 for( int w=0; w < 7;w++){
   cout << week[w] << "    ";
 }
 cout << "\n__-------------------------------------------------__\n";
 cout << "\n";
 int Break=1;

 for(int w=0;w<FirstDayofMonth;w++){
   cout << "   |   ";
   ++Break;
 }
 for(int d=1;d<=NumberofDaysInMonth;d++){
   if(d==reminder) {
     cout << " " << d <<"    ";
   } else{
     cout << d <<"  |  ";
   }
 
 if(d<10)
   cout << " ";
 if(Break>6)
 {
   cout << endl;
   Break=0; 
 }
 ++Break;
 }

}

struct Date {
    int d, m, y;  //for day month year
};

const int monthDays[12]
    = { 31, 28, 31, 30, 31, 30,
       31, 31, 30, 31, 30, 31 };
 
int countLeapYears(Date d)
{
    int years = d.y;
    if (d.m <= 2)
        years--;
    return years / 4
           - years / 100
           + years / 400;
}
 

int getDifference(Date dt1, Date dt2)
{
   
    long int n1 = dt1.y * 365 + dt1.d;
 
  
    for (int i = 0; i < dt1.m - 1; i++)
        n1 += monthDays[i];
 
    
    n1 += countLeapYears(dt1);
 
    long int n2 = dt2.y * 365 + dt2.d;
    for (int i = 0; i < dt2.m - 1; i++)
        n2 += monthDays[i];
    n2 += countLeapYears(dt2);
    return (n2 - n1);
}

bool isLeap(int y)
{
    if (y%100 != 0 && y%4 == 0 || y %400 == 0)
        return true;
 
    return false;
}
 

int offsetDays(int d, int m, int y)
{
    int offset = d;
 
    switch (m - 1)
    {
    case 11:
        offset += 30;
    case 10:
        offset += 31;
    case 9:
        offset += 30;
    case 8:
        offset += 31;
    case 7:
        offset += 31;
    case 6:
        offset += 30;
    case 5:
        offset += 31;
    case 4:
        offset += 30;
    case 3:
        offset += 31;
    case 2:
        offset += 28;
    case 1:
        offset += 31;
    }
 
    if (isLeap(y) && m > 2)
        offset += 1;
 
    return offset;
}
 

void revoffsetDays(int offset, int y, int *d, int *m)
{
    int month[13] = { 0, 31, 28, 31, 30, 31, 30,
                      31, 31, 30, 31, 30, 31 };
 
    if (isLeap(y))
        month[2] = 29;
 
    int i;
    for (i = 1; i <= 12; i++)
    {
        if (offset <= month[i])
            break;
        offset = offset - month[i];
    }
 
    *d = offset;
    *m = i;
}
void addDays(int d1, int m1, int y1, int x)
{
    int offset1 = offsetDays(d1, m1, y1);
    int remDays = isLeap(y1)?(366-offset1):(365-offset1);
 
    int y2, offset2;
    if (x <= remDays)
    {
        y2 = y1;
        offset2 = offset1 + x;
    }
 
    else
    {
        
        x -= remDays;
        y2 = y1 + 1;
        int y2days = isLeap(y2)?366:365;
        while (x >= y2days)
        {
            x -= y2days;
            y2++;
            y2days = isLeap(y2)?366:365;
        }
        offset2 = x;
    }
 
    
    int m2, d2;
    revoffsetDays(offset2, y2, &d2, &m2);
 
    cout << "d2 = " << d2 << ", m2 = " << m2
         << ", y2 = " << y2;
}


void subDays(int day, int month , int year , int x)
{
	int newDay=0;
  newDay=x-day;
  day=newDay;
  while(day<=0)
  {
   day=day+30;
   month=month-1;
   }
  
  while(month<=0)
  {
   month=month+12;
   year=year-1;
  }
  
  cout<< "The date is \n" << "day = "<<day<< "Month = "<<month<< "Year = "<<year;
}



int main()

{

	int mth,yr,x;
	int Reminder;
	int d,m,y;
	char remiderMessage[200];
 
	cout<<"Enter calender(date) which you want to be displayed\n";
	cout<<"Enter year:";
	cin>>yr;
	cout<<"Enter month:";
	cin>>mth;
	cout<<endl;
calender C(mth,yr);
cout<<endl;
C.setFirstDay();
cout<<endl;
C.display(0) ;
cout<<endl;

  cout << "\n";
 cout << "Press enter key to Show options\n";
 getch();
  
	int select;  
	cout<<"1)	Add a Reminder Note on a specific day\n"
  		<<"2)	Calculate difference between two dates\n"
  		<<"3)	Find a future date\n"
  		<<"4)	Find a previous date\n";
  	cin>>select;
  	
  	if(select==1){
	  
  			cout << "Enter the Reminder day: ";
 			cin >> Reminder;
 			cout << "Enter the reminder message:";
			cin.ignore();
 			cin.getline(remiderMessage,200);
 
 			cout << "\n\n";
 
			C.display(Reminder) ;
 
 			cout << "\n==================Set Reminder of day=====================\n";
 			cout <<  Reminder;
 			cout << "\n" << remiderMessage;
 			getch();
  	}
  		
  			if(select==2){
  			
			Date dt1;
  			cout<<"Enter the day :";
  			cin>>dt1.d;
  			cout<<"Enter the Month (1):";
  			cin>>dt1.m;
  			cout<<"Enter the year (1):";
  			cin>>dt1.y;
  	
  			cout<<endl;
	  		Date dt2;
  			cout<<"Enter the day (2):";
  			cin>>dt2.d;
  			cout<<"Enter the Month (2):";
  			cin>>dt2.m;
  			cout<<"Enter the year (2):";
  			cin>>dt2.y;
   			cout<<endl;
			cout << "Difference between two dates is " << getDifference(dt1, dt2);
	}
			
			if(select==3){
			
 			cout<<"\n enter days=";
 			cin>>d;
 			cout<<"\n enter month=";
 			cin>>m;
 			cout<<"\n enter year=";
 			cin>>y;
 			
 			cout<<"\n enter number of days you want to add= ";
 			cin>>x;
			addDays(d, m, y, x);
		}
			
			if(select==4){
		
 			cout<<"\n enter days=";
 			cin>>d;
 			cout<<"\n enter month=";
 			cin>>m;
 			cout<<"\n enter year=";
 			cin>>y;
 			
 			cout<<"\n enter number of days you want to go behind = ";
 			cin>>x;
			subDays(d, m, y, x);
	}
 
}



