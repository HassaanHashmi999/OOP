#include <iostream>
using namespace std;


struct axis
{
	int x1;
	int x2;
	int x4;
	int x3;
	int y1;
	int y2;
	int y3;
	int y4;
	int a,h;

};
void quantity(axis *rec, int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<"For "<<i+1<<" rectangle:"<<endl;
		cout<<"Enter first X coordinate of the rectangle:";
		cin>>rec[i].x1;
		cout<<"Enter Second X coordinate of the rectangle:";
		cin>>rec[i].x2;
		cout<<"Enter third X coordinate of the rectangle:";
		cin>>rec[i].x3;
		cout<<"Enter fourth X coordinate of the rectangle:";
		cin>>rec[i].x4;
		cout<<"Enter first Y coordinate of the rectangle:";
		cin>>rec[i].y1;
		cout<<"Enter Second Y coordinate of the rectangle:";
		cin>>rec[i].y2;
		cout<<"Enter third Y coordinate of the rectangle:";
		cin>>rec[i].y3;
		cout<<"Enter fourth Y coordinate of the rectangle:";
		cin>>rec[i].y4;
	}
	
}
void area(axis *rec, int n)
{ 

    int len,wid;
	for(int i=0;i<n;i++)
	{
		cout<<"For "<<i+1<<" rectangle:"<<endl;
		wid=rec[i].x1-rec[i].x2;
		
		len=rec[i].y2-rec[i].y4;
		
		rec[i].a=wid*len;
		if(rec[i].a<0)
		rec[i].a=rec[i].a*-1;
		cout<<"The area is:"<<rec[i].a<<endl;
	}
}
void order(axis *rec, int n)
{ 
int aesc;
    for (int i = 0; i < n; ++i)   
    {
        for (int j = i + 1; j < n; ++j)
        {
            if (rec[i].a > rec[j].a)
            {
                aesc = rec[i].a;
                rec[i].a = rec[j].a;
                rec[j].a = aesc;
            }
        }
        
    }
    cout<<"The area of rectangles in ascending order:";
    for (int i = 0; i < n; ++i)
    {
       
        cout<<" "<<rec[i].a<<endl;
     
    }
   
}

void over(axis *rec, int n)
{
	int len,wid;
	for(int i=0;i<n;i++)
	{
		cout<<"For "<<i+1<<"rectangle in asending order with largest rectangle:"<<endl;
		
		
	if(rec[0].x1 > rec[i+1].x4 || rec[i+1].x1 > rec[0].x4 || rec[0].y1 > rec[i+1].y4 || rec[i+1].y1 > rec[0].y4)
	{
		cout<<"it does not overlap"<<endl;
	}
	}
}




int main()
{
	int n;
	cout<<"Input the number of rectangles you want to make:";
	cin>>n;
	axis rec[n];
	
		quantity(rec,n);
		area(rec, n);
		order(rec,n);
		over(rec,n);
}
 	
