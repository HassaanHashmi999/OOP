#include<iostream>
using namespace std;



struct Salary{
double fixedSalary ; 
double comission; 
};
struct Sales_Person{
int emp_ID;
string emp_Name; 
double Sales;
Salary emp_sal; //salary of the employee
};
struct Book{
int id;
int type;
string bookName;
string authorName;
double price;
};
struct Customer{
int cust_No;
string cust_Name; 
string cust_Address; 
Book bk[]; 
};

void totalSales(int s)
{
	cout<<"total sales:"<<s<<endl;
}
void totalSalesBySalesPerson(Sales_Person *emp,int e) 
{
	cout<<"total sales by "<<e<<emp[e].Sales<<endl;
}
 void topSalesPerson(Sales_Person *emp)
{
	if(emp[0].Sales>emp[1].Sales && emp[0].Sales>emp[2].Sales)
	cout<<"Epmloyee no 1 has the most sales";
	if(emp[1].Sales>emp[0].Sales && emp[1].Sales>emp[2].Sales)
	cout<<"Epmloyee no 1 has the most sales";
	if(emp[2].Sales>emp[1].Sales && emp[2].Sales>emp[2].Sales)
	cout<<"Epmloyee no 1 has the most sales";
}
void commissionSalesPerson(Sales_Person *emp,int e) 
{
	cout<<	emp[e].emp_sal.comission;
}
void totalSalary(Sales_Person *emp) 
{
	int amount;
	for (int i=0;i<3;i++ )
	{
		amount=emp[i].emp_sal.fixedSalary+emp[i].emp_sal.comission;
		
	}
	cout<<amount;
}
void booksInventory(int ss)
{
	int I=10-ss;
	cout<<"THE amount of books Left:"<<I;
}
void booksInventoryByType(int SF,int H, int A)
{
	cout<<"History books left:"<<H<<endl;
	cout<<"Sci Fi books left:"<<SF<<endl;
	cout<<"Adventure books left:"<<A<<endl;
}

int main()
{
	Sales_Person emp[3];
	Book bks[10];
	int b=10,s,e,ss,H=3,A=4,SF=3;
	cout<<"Total books are 10 "<<endl<<"Histroy:"<<H<<" Adventure:"<<A<<" SI_FI:"<<SF<<endl;
	for(int i=0;i<10;i++)
		{
		cout<<"(before sales)BOOK no :"<<i+1<<endl;
		cout<<"Enter BOOK ID NO:";
		cin>>bks[i].id;
		cout<<"Enter name:";
		cin >>bks[i].bookName;
		cout<<"Enter TYPE: 1)History 2)Sci-Fi 3)Adventure";
		cin>>bks[i].type;
		cout<<"Enter author name:";
		cin>>bks[i].authorName;
		cout<<"Enter Price:";
		cin>>bks[i].price;
		}

	for(int i=0;i<3;i++)
	{	
	
	int n,sold=0;
	Customer cust[n];
	
		cout<<"EMP :"<<i+1<<endl;
		cout<<"Enter EMPLOYE ID NO:";
		cin>>emp[i].emp_ID;
		cout<<"Enter name:";
		cin >>emp[i].emp_Name;
		cout<<"Enter number of sales (No of books) in the week:";
		cin>>emp[i].Sales;
		s=emp[i].Sales+s;
		cout<<"Enter the number of customers the employee has sold to:";
		cin>>n;
		for(int j=0;j<n;j++)
		{ 
	cout<<"Enter coustomer No:";
		cin>>cust[j].cust_No;
		cout<<"Enter the name of the coustomer:";
		cin>>cust[j].cust_Name;
		cout<<"Enter coustomer Adress:";
		cin>>cust[j].cust_Address;
		
			cout<<"Enter the number of books sold to the customer:";
			cin>>sold;
			ss=sold+ss;
		for(int k=0;k<sold;k++)
		{
		
		cout<<"BOOK :"<<k+1<<endl;
		cout<<"Enter BOOK ID NO:";
		cin>>cust[j].bk[k].id;
		cout<<"Enter name:";
		cin >>cust[j].bk[k].bookName;
		cout<<"Enter TYPE: 1)History 2)Sci-Fi 3)Adventure";
		cin>>cust[j].bk[k].type;
		if(cust[j].bk[k].type==1)
		--H;
		if(cust[j].bk[k].type==2)
		--SF;
		if(cust[j].bk[k].type==3)
		--A;
		cout<<"Enter author name:";
		cin>>cust[j].bk[k].authorName;
		cout<<"Enter Price:";
		cin>>cust[j].bk[k].price;
	}
		}
		emp[i].emp_sal.fixedSalary=15000;
			emp[i].emp_sal.comission=emp[i].Sales*800*0.02;
		
	}
	totalSales(s);
	cout<<"Enter the number of employee you want to calculate sales for:";
	cin>>e;
	totalSalesBySalesPerson(emp,e-1);
	topSalesPerson(emp);
	cout<<"Enter the number of employee you want to calculate SALARY for:";
	cin>>e;
	cout<<"Salary of the Employee: "<<e<<":";
	commissionSalesPerson(emp,e-1);
	cout<<"Total Amount Owner has to pay to all employess:";
	totalSalary(emp);
	booksInventory(ss);
	booksInventoryByType(SF,H,A);
}

