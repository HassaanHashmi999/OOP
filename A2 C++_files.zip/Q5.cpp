#include<iostream>
#include <stdlib.h>     
#include <time.h> 
#pragma GCC diagnostic push
#pragma GCC diagnostic warning "-fpermissive"



#pragma GCC diagnostic pop
using namespace std;
int s,p3,p2;
void addPlayers(string n,string t,double p);

class Player{
private:
string name;
string type; 
double points; //randomly assign points between 30 to 40 randomly

public:

void addPlayers(string n,string t,double p)
{
	p= rand() % 40 + 30;
	name=n;
	type=t;
	points=p;
	cout<<" Name:"<<name<<endl<<"type :"<<type<<endl<<"points:"<<points<<endl<<endl;

}
void returnPlayers(string n,string t)
{
	name=n;
	type=t;

	cout<<" Name:"<<name<<endl<<"type :"<<type<<endl<<endl<<endl;
}

};
Player plr1,plr2,plr3,plr4,plr5,plr6,plr7,plr8,plr9,plr10,plr11,plr12,plr13,plr14,plr15;//even if we use loop the name can not be changed the so declaring many variables of same type
class Team{
public:
string teamName;
int teamRank;

void assignRanks(int R)
{
	R=rand() % 100 + 1;
	cout<<"Rank is::"<<R<<endl;
}
void printTeamRanks(int z)
{
	z=rand() % 100 + 1;
	int l=rand() % 100 + 1;
	cout<<"Rank is now::"<<z+l<<endl;
}
void UpdatePlayerPoints(int o)
{
	
	cout<<"points given are ::"<<o<<endl;
}
void bestPlayersInMatch(int e)
{
	cout<<e+1<<" is the best player in the match"<<endl;
}
void teamSelection(int j)
{
	if(j==1)
		{
		cout<<"1)";
	plr1.returnPlayers("Kashif","false(sold)");
}
	if(j==2)
		{
		cout<<"2)";
	plr2.returnPlayers("Adil","false(sold)");
}
	if(j==3)
		{
			cout<<"3)";
	plr3.returnPlayers("ALI","false(sold)");
}
	if(j==4)
		{
		cout<<"4)";
	plr4.returnPlayers("Asif"," false(sold)");
}
	if(j==5)
		{
	cout<<"5)";
	plr5.returnPlayers("Kamran","false _sold");
}
	if(j==6)
		{
		cout<<"6)";
	plr6.returnPlayers("Touqueer","false _sold");
}
	if(j==7)
		{
	cout<<"7)";
	plr7.returnPlayers("Umair","false _sold");
}
	if(j==8)
		{
		cout<<"8)";
	plr8.returnPlayers("Hina","false _sold");
}
	if(j==9)
		{
	cout<<"9)";
	plr9.returnPlayers("Sana","false _sold");
}
	if(j==10)
		{
		cout<<"10)";
	plr10.returnPlayers("Anas","false _sold");
}
	if(j==11)
		{
	cout<<"11)";
	plr11.returnPlayers("Awais","false _sold");
}
	if(j==12)
		{
	cout<<"12)";
	plr12.returnPlayers("Sania","false _sold");
}
	if(j==13)
		{
			cout<<"13)";
	plr13.returnPlayers("Saad","false _sold");
}
	if(j==14)
		{
			cout<<"14)";
	plr14.returnPlayers("Ammar","false _sold");
}
	if(j==15)
		{
			cout<<"15)";
	plr15.returnPlayers("Amir","false _sold");
}















}
};
class Match{
public:
int Match_No;
Team homeTeam;
Team awayTeam;
void generateMatchStats(int R1,int R2)
{
	if(R1>R2)
	{
		cout<<"Home team wins"<<endl;
	
			for(int e=0;e<3;e++){
	
	p2= rand() % 20 + 10;
 s=p2;
p3= rand() % 10 + 5;
cout<<"player "<<e+1<<" ";
	homeTeam.UpdatePlayerPoints(p2);
cout<<"player "<<e+1<<" ";
	awayTeam.UpdatePlayerPoints(p3);
	if(s<p2)
	homeTeam.bestPlayersInMatch(e-1);
	
}
	}
	else
	{
		cout<<"Away team wins"<<endl;
				for(int e=0;e<3;e++){
	
	p2= rand() % 20 + 10;
 s=p2;
 	p3= rand() % 10 + 5;
cout<<"player "<<e+1<<" ";
	homeTeam.UpdatePlayerPoints(p3);
cout<<"player "<<e+1<<" ";
	awayTeam.UpdatePlayerPoints(p2);
	
}
	if(s<p2)
	awayTeam.bestPlayersInMatch(e-1);
	}

}
};
int main()
{	int i,j;
	double p=1.2;
	Team t1,t2,t3,t4;
	Match m;
	cout<<"1)";
	plr1.addPlayers("Kashif","defenfsive",p);
	cout<<"2)";
	plr2.addPlayers("Adil","defenfsive",p);
	cout<<"3)";
	plr3.addPlayers("ALI","defenfsive",p);
	cout<<"4)";
	plr4.addPlayers("Asif","defenfsive",p);
	cout<<"5)";
	plr5.addPlayers("Kamran","defenfsive",p);
	cout<<"6)";
	plr6.addPlayers("Touqueer","defenfsive",p);
	cout<<"7)";
	plr7.addPlayers("Umair","attacking",p);
	cout<<"8)";
	plr8.addPlayers("Hina","attacking",p);
	cout<<"9)";
	plr9.addPlayers("Sana","attacking",p);
	cout<<"10)";
	plr10.addPlayers("Anas","attacking",p);
	cout<<"11)";
	plr11.addPlayers("Awais","attacking",p);
	cout<<"12)";
	plr12.addPlayers("Sania","attacking",p);
	cout<<"13)";
	plr13.addPlayers("Saad","defenfsive",p);
	cout<<"14)";
	plr14.addPlayers("Ammar","attacking",p);
	cout<<"15)";
	plr15.addPlayers("Amir","defenfsive",p);
	cout<<"Enter type of player you want to display: 1)Attack 2)defensive   :::";
	cin>>i;
	cout<<endl;
	if(i==1)
	{
	cout<<"7)";
	plr7.returnPlayers("Umair","attacking");
	cout<<"8)";
	plr8.returnPlayers("Hina","attacking");
	cout<<"9)";
	plr9.returnPlayers("Sana","attacking");
	cout<<"10)";
	plr10.returnPlayers("Anas","attacking");
	cout<<"11)";
	plr11.returnPlayers("Awais","attacking");
	cout<<"12)";
	plr12.returnPlayers("Sania","attacking");
	cout<<"14)";
	plr14.returnPlayers("Ammar","attacking");
	
	}	
	else if (i==2)
	{
	cout<<"1)";
	plr1.returnPlayers("Kashif","defenfsive");
	cout<<"2)";
	plr2.returnPlayers("Adil","defenfsive");
	cout<<"3)";
	plr3.returnPlayers("ALI","defenfsive");
	cout<<"4)";
	plr4.returnPlayers("Asif","defenfsive");
	cout<<"5)";
	plr5.returnPlayers("Kamran","defenfsive");
	cout<<"6)";
	plr6.returnPlayers("Touqueer","defenfsive");
	cout<<"13)";
	plr13.returnPlayers("Saad","defenfsive");
	cout<<"15)";
	plr15.returnPlayers("Amir","defenfsive");
	}
	cout<<"Team 1 ";
	t1.assignRanks(p);
	cout<<"Team 2 ";
	t2.assignRanks(p);
	cout<<"Team 3 ";
	t3.assignRanks(p);
	cout<<"Team 4 ";
	t4.assignRanks(p);
	cout<<"Enter the number of player team selects:";
	cin>>j;
	for(j=1;j<16;){
	int k=1,d=0;
	t1.teamSelection(j);
	cout<<"Enter the number of player team selects: "<<" for team "<<k<<" :";
	cin>>j;
	k++;
	if(k>4)
	k=1;
	d++;
	if(d==12)
	j=0;
}
	cout<<"total number of matches played are are 24, 6 by each team"<<endl;
	int R1,R2;
	for(int q=0;q<24;q++)
	{
	cout<<"Enter points for Home team:";
	cin>>R1;
	cout<<"Enter points for Away team:";
	cin>>R2;
	m.generateMatchStats(R1,R2);
	}
	cout<<"Team 1 ";
	t1.printTeamRanks(p);
	cout<<"Team 2 ";
	t2.printTeamRanks(p);
	cout<<"Team 3 ";
	t3.printTeamRanks(p);
	cout<<"Team 4 ";
	t4.printTeamRanks(p);
	
	
}

