#include <iostream>
using namespace std;

struct customer
{
	string date,qoute;
	int t1[2],t2[2];
	int task;
};



void display(customer *c, int n, int cn)
{
		int format;
		int del;
		cout<<"Date is  :";
		cout<<c[cn].date;
		cout<<c[cn].qoute;
		cout<<"Enter 1)to Change 2)don't change  ::";
		cin>>format;
		switch(format)
		{
			case 1:
				cout<<"Enter new Qoute:";
				cin>>c[cn].qoute;
				break;
			case 2:
				cout<<c[cn].qoute;
				break;
			default:
				cout<<c[cn].qoute;
		}
		cout<<"Enter the format of time PRESS 1)24HOUR 2)12HOUR  ::";
		cin>>format;
		switch(format)
		{
			case 1:
				cout<<c[cn].t1[0]<<":"<<c[cn].t1[1];
				break;
			case 2:
				cout<<c[cn].t1[0]<<":"<<c[cn].t1[1];
				break;
			default:
				cout<<c[cn].t1[0]<<":"<<c[cn].t1[1];
		}
	for(int i=0;i<c[cn].task;i++)
	{
		cout<<"task:"<<i+1;
	}
	cout<<"which task do you want to delete:";
	cin>>del;
	for(int i=0;i<c[cn].task;i++)
	{	
		if(i!=del)
		cout<<"task:"<<i+1;
	}
		
}

int main() 
{
	cout<<"Enter the number of customers applied:";
	int n;
	cin>>n;
    customer c[n];
	int format;
	for(int i=0;i<n;i++)
	{
		cout<<"Enter Data for customer.no"<<i+1<< " "<<endl;
		cout<<"Enter Date in whatever format :";
		cin>>c[i].date;
		c[i].qoute	="The day is beautiful";
		cout<<"ENTER THE TIME hours:";
		cin>>c[i].t1[0];
		cout<<"ENTER THE TIME minutes:";
		cin>>c[i].t1[1];
		c[i].t2[1]=c[i].t1[1];
		c[i].t2[0]=c[i].t1[0]-12;
		cout<<"Enter the number of tasks:";
		cin>>c[i].task;
	}
	int cn;
	cout<<"enter the number of customer you want to display information for:";
	cin>>cn;
	display( c,n,cn+1);
	
	return 0;
	}
	
