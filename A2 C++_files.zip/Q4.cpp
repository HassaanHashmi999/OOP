#include<iostream>
#include <stdio.h>     
#include <stdlib.h>     
#include <time.h>   
using namespace std;
	int l,su,q;
	string w;
struct card{
	char i[13];
	string suit[4];
};
struct player{
int id;
int t; 
card cardsInHand;
};


void chooseDealer(player *p)
{
	srand (time(NULL));

  int k,j;
  k=rand() % 4;
 	cout<<"player: "<<p[k].id<<" is the dealer"<<endl;
 	j=k+1;
 
 	if(j>=4)
 	{
 		j=0;
	 }
	 	q=j;
	 cout<<"player: "<<p[j].id<<" is the trump caller"<<endl;
}
int Deal_and_Tumps(player *p)
{	
int d;
	for(int pp=0;pp<4;pp++){
		
for(int i=0;i<13;i++){

	l=rand() % 13+1;
	su=rand() % 4+1;
	d=i*pp;
	if(d==20)
	{
		cout<<"enter trump card from player "<<p[q].id<<":";
		cin>>w;
	}
	  if (l == 1) 	p[pp].cardsInHand.i[i]='A';
      if (l == 2) 	p[pp].cardsInHand.i[i]= '2';
      if (l == 3) 	p[pp].cardsInHand.i[i]='3';
      if (l == 4) 	p[pp].cardsInHand.i[i]= '4';
      if (l == 5) 	p[pp].cardsInHand.i[i]= '5';
      if (l == 6) 	p[pp].cardsInHand.i[i]= '6';
      if (l == 7) 	p[pp].cardsInHand.i[i]= '7';
      if (l == 8) 	p[pp].cardsInHand.i[i]= '8';
      if (l == 9) 	p[pp].cardsInHand.i[i]= '9';
      if (l == 10) 	p[pp].cardsInHand.i[i]= '10';
      if (l == 11) 	p[pp].cardsInHand.i[i]= 'J';
      if (l == 12) 	p[pp].cardsInHand.i[i]= 'Q';
      if (l == 13) 	p[pp].cardsInHand.i[i]= 'K';
      
      if (su == 1) p[pp].cardsInHand.suit[su-1] ="Diamonds";
      if (su == 2) p[pp].cardsInHand.suit[su-1] = "Hearts";
      if (su == 3) p[pp].cardsInHand.suit[su-1] ="Spades";
      if (su == 4) p[pp].cardsInHand.suit[su-1] = "Clubs";

}
}
	
}
		


void revealCards(player *p)
{
	int c1,c2,c3,c4;
	for(int i=0;i<4;i++)
	{
		
	cout<<"cards for player of id: "<<p[i].id<<endl;
	for(int j=0;j<13;j++)
	{	su=rand() % 4+1;
	
	
	
		cout<<p[i].cardsInHand.i[j];
		cout<<"  of   "<<p[i].cardsInHand.suit[su-1];
      cout<<endl;
      
	}
	
	cout<<endl;
   }
	
}


int main ()
{
	player p[4];

	cout<<"Enter the info for the players"<<endl;
	for(int i=0;i<4;i++)
	{	
		cout<<"Player"<<i+1<<":";
		cout<<"ID:";
		cin>>p[i].id;
	}
	
	chooseDealer(p);
	
	Deal_and_Tumps(p);
	revealCards(p);
}
