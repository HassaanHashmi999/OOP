#include<iostream>
using namespace std;



class task{
private:
int id;
int dur;
int s_Time; //start time of each task
int e_Time; //end time of each task
int* dep; 
public:
int addTasks(int i, int j,int k )
{
	id=i;
	s_Time=j;
	e_Time=k;
	dur=e_Time-s_Time;
	return dur;
	
}
void setTaskDuration(int dur,int w)
{
	int S;
	cout<<"how much duration is changed for all tasks";
	cin>>S;
dur=dur+S;
cout<<"Now the duration is "<<dur<<" for "<<w<<"task"<<endl;

}//change task duration of all tasks
void set_nth_TaskDuration(int dur){

	int E;
	cout<<"how much duration is changed for this task";
	cin>>E;
	dur=dur-E;
	cout<<"now the duration is::"<<dur<<endl;

}//change duration of a specific task
void printTaskDependencyList(int f)
{
cout<<"this task is depened on "<<f<<" task"<<endl;

}//print dependencies of a specific task
};
class project{
private:
int id;
int PT; //duration of project
task* tasks;
public:
// provide definitions of following functions...
Project();// default constructor
void Project(task *ts, int k)
{
cout<<"Number of tasks in project "<<k;
int id;
int st; //start time of each task
int et;
int r;

	for(int j=0;j<k;j++)
	{
		int q;
		cout<<"Enter the info of task "<<j+1;
		cout<<endl<<"Enter the id of the task";
		cin>>id;
		cout<<"enter the starting time of the task:";
		cin>>st;
		cout<<"enter the end time of the task: ";
		cin>>et;
		ts[j].addTasks(id ,st,et);
		PT=PT+ts[j].addTasks(id ,st,et);
		r=et-st;
		ts[j].setTaskDuration(r,j+1);
		cout<<"enter the task you want to change duration for::";
		cin>>q;
		if(j+1==q)
		{
			ts[q].set_nth_TaskDuration(et-st);
		}
		cout<<"enter the task you want to check dependency for::";
		cin>>q;
			if(j+1==q)
		{
			ts[q].set_nth_TaskDuration(j);
		}
	}
	
	}//print completion time of the project


void completionTime(){

cout<<"the completion time is :: without change ::"<<PT<<endl;
}//print completion time of the project

};
int main()
{	int l,k;
	
	
	cout<<"enter the number of projects:";
	cin>>l;
	project p[l];
	for(int i=0;i<l;i++)
	{
	cout<<"enter the number of tasks ::";
	cin>>k;
	task t[k];
	p[i].Project(t,k);
	
    }
	
}
