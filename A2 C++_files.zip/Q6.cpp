#include<iostream>
using namespace std;


struct Runway {
int id;
string type;
int availability;
int s_Time; //start time of each task
};




class Flight{
private:
// think about the private data members...
string flight_No; //
double arrivalT; //arrival time which is known at the departure.
double FlyT; //how long can the fuel last it no runway is available
double SLT; //

public:
// constructors
// provide definitions of following functions...
void addFlight(double i, double j ,double k) //function to add flight information and to output them
{
	arrivalT=i;
	FlyT=j;
	SLT=k;
	cout<<"The estimated time of arrival is:"<<arrivalT<<" Hours.minutes"<<endl<<endl<<"BY the fuel left in the plane it can last upto"<<FlyT<<" Hours.minutes"<<endl<<endl<<"Scheduled_landing_Time: " <<SLT<<endl;                  
}
void UpdateRemainingFlyTime(int tm)
{
	SLT=SLT+tm;
	cout<<"Now time is::"<<SLT;
}
void UpdateLandingInfo(Runway *r, int rn)
{
	for(int j=0;j<3;j++)
	{   
	if(j==rn){
	
		cout<<"Runway no."<<j+1<<endl;
		cout<<"Id of the runway:"<<r[j].id<<endl;
		
		
		if(r[j].availability==0)
		{
			cout<<"The runway going to be free(time left in minutes): "<<SLT;
		}
	}
	}
}
};
/*Special class with only one instance during execution of the program, there is only air traffic
controller and landing time is allocated to plans in a centralized fashion*/
class AirController {
private:

int f;//the flight that that has contacted the air control only one case(one instance mentioned in the question)
int time;
int rn;

public:

void RunwayStatus(Runway *r)//prints the status of all the runways
{
	for(int j=0;j<3;j++)
	{
		cout<<"Runway no."<<j+1<<endl;
		cout<<"Id of the runway:"<<r[j].id<<endl;
		cout<<"The runway is ";
		if(r[j].availability==0)
		{
			cout<<" Not avalible "<<endl;
		}
		else
		{
			cout<<"Avalible"<<endl;
		}
		cout<<"The type of the runway "<<r[j].type<<endl;
		if(r[j].availability==0)
		{
			cout<<"The runway going to be free(time in minutes): "<<r[j].s_Time;
		}
		
	}

}
void FlightContact(int fn)
{
	f=fn;
cout<<"the flight that has contacted the air control is :: "<<f;

}//removed a function it is better not to use a function in a function to only print data

void AssignRunway(Runway *r, int rn, int time )
{
	for(int j=0;j<3;j++)
	{   
	if(j==rn){
	
		cout<<"Runway no."<<j+1<<endl;
		cout<<"Id of the runway:"<<r[j].id<<endl;
		cout<<"The runway is ";
		if(r[j].availability==0)
		{
			cout<<" Not avalible "<<endl;
		}
		else
		{
			cout<<"Avalible"<<endl;
		}
		cout<<"The type of the runway "<<r[j].type<<endl;
		if(r[j].availability==0)
		{
			cout<<"The runway going to be free(time in minutes): "<<time;
		}
	}
	}
}

};


int main()
{	
	AirController AC;
	int fn;
	int tm;
	int rw;	
	double atime,FN,ltime;
	int fs;
	Runway r[3];
	cout<<"Enter the number of flights that are going to land in 10 minutes:";
	cin>>fs;
	Flight F[fs];
	for(int i=0;i<fs;i++)
	{
		cout<<"Enter data for flight no "<<fs+1;
		cout<<"Enter the arrival time of the flight:";//as the given variable is in double the time is entered with a decimal
		cin>>atime;
		cout<<"Enter the the time(feul left) the airplane can stay in air";
		cin>>ltime;
		cout<<"Scheduled_landing_Time:";
		cin>>FN;
		F[i].addFlight(atime,ltime,FN);
		
	}
	for(int j=0;j<3;j++)
	{
		cout<<"Runway no."<<j+1<<endl;
		cout<<"Enter the id of the runway:";
		r[j].id;
		cout<<"Enter 1 if the runaway is avalible else press 0:";
		r[j].availability;
		cout<<"Enter the type of the runway";
		cin>>r[j].type;
		if(r[j].availability==0)
		{
			cout<<"when is the runway going to be free( time(minutes) ) :";
			cin>>r[j].s_Time;
		}
		
	}
	AC.RunwayStatus(r);
	cout<<"Enter the flight that needs to contact the air controller to change runway(enter in 1 2 3 4 and so on):";
	cin>>fn;
	AC.RunwayStatus(r);
	F[fn-1].addFlight(atime,ltime,FN);
	cout<<"Enter the time the flight has to wait:";
	cin>>tm;
	cout<<"Enter the runway assigned to the plane:";
	cin>>rw;
	AC.AssignRunway(r,rw-1,tm);//assigns
	
	F[fn-1].UpdateRemainingFlyTime(tm); //This is updated once the flight contacts AirController adding time to landing time 
    F[fn-1].UpdateLandingInfo(r,rw-1);
	
	
}




